import aiohttp
import asyncio
import csv
import re
import sys
from bs4 import BeautifulSoup

def convert_price(price):
    """
    Convert crore, lakhs, millions and Thousand into numbers

    :param price: str
    :return: float
    """
    if price.endswith('Crore'):
        return round(float(price[:-5]) * 10000000)
    elif price.endswith('Lakh'):
        return round(float(price[:-4]) * 100000)
    elif price.endswith('Million'):
        return round(float(price[:-7]) * 1000000)
    elif price.endswith('Arab'):
        return round(float(price[:-4]) * 1000000000)
    elif price.endswith('Thousand'):
        return round(float(price[:-8]) * 1000)
    else:
        return round(float(price))
    
def convert_size(size):
    """
    Convert kanal merla into sqft

    :param size: str
    :return: float
    """
    if size.endswith('Marla'):
        return round(float(size[:-5].replace(",", "")) * 225)
    elif size.endswith('Kanal'):
        return round(float(size[:-5].replace(",", "")) * 4500)
    elif size.endswith('Sq. Yd.'):
        return round(float(size[:-7].replace(",", "")) * 9)
    else:
        return round(float(size))
    

def text(tag, datatype="str"):
    """
    This function will return the text of the tag.

    :param tag: tag object
    :param datatype: num or str or price, size
    :return: price in number or string
    """
    if tag is None and datatype == "num":
        return 0
    if datatype == "num":
        try:
            return int(tag.text.strip())
        except ValueError:
            return 0
    if tag is None and datatype == "str":
        return ""
    if datatype == "str":
        return tag.text.strip()
    if tag is None and datatype == "price":
        return 0.0
    if datatype == "price":
        return convert_price(tag.text.strip())
    if tag is None and datatype == "size":
        return 0.0
    if datatype == "size":
        return convert_size(tag.text.strip())
    
async def scrape_house_details(session, page_url, baths, beds, location, price, size, date_added, title):
    async with session.get(page_url) as response:
        content = await response.text()
        soup = BeautifulSoup(content, 'html.parser')

        script_content = soup.find('script').text
        if not script_content:
            return None
        latitude_pattern = r'"latitude":(\d+\.\d+)'
        latitude_match = re.search(latitude_pattern, script_content)
        latitude = latitude_match.group(1) if latitude_match else None

        longitude_pattern = r'"longitude":(\d+\.\d+)'
        longitude_match = re.search(longitude_pattern, script_content)
        longitude = longitude_match.group(1) if longitude_match else None

        property_type_pattern = r'"property_type":"(.*?)"'
        property_type_match = re.search(property_type_pattern, script_content)
        property_type = property_type_match.group(1).replace(';', '') if property_type_match else None

        number_of_photos_pattern = r'"number_of_photos":(\d+)'
        number_of_photos_match = re.search(number_of_photos_pattern, script_content)
        number_of_photos = number_of_photos_match.group(1) if number_of_photos_match else None

        loc_region_name_pattern = r'"loc_region_name":"(.*?)"'
        loc_region_name_match = re.search(loc_region_name_pattern, script_content)
        loc_region_name = loc_region_name_match.group(1).replace(';', '') if loc_region_name_match else None

        marketed_by_pattern = r'"marketed_by":"(.*?)"'
        marketed_by_match = re.search(marketed_by_pattern, script_content)
        marketed_by = marketed_by_match.group(1) if marketed_by_match else None

        purpose_pattern = r'"purpose":"(.*?)"'
        purpose_match = re.search(purpose_pattern, script_content)
        purpose = purpose_match.group(1) if purpose_match else None

        return {
            "page_url": page_url,
            "title": text(title, datatype="str"),
            "location": text(location),
            "price": text(price, datatype="price"),
            "bedrooms": text(beds, datatype="num"),
            "baths": text(baths, datatype="num"),
            "size": text(size, datatype="size"),
            "date_added": text(date_added, datatype="str"),
            "purpose": purpose,
            "property_type": property_type,
            "latitude": latitude,
            "longitude": longitude,
            "number_of_photos": number_of_photos,
            "province": loc_region_name,
            "agency": marketed_by
        }

async def scrape_city(city_name, city_id, pages_range):
    house_info = []

    async with aiohttp.ClientSession() as session:
        tasks = []

        for page_number in range(1, pages_range + 1):
            url = f'https://www.zameen.com/Homes/{city_name}-{city_id}-{page_number}.html'
            print(url)

            house_list = []

            async with session.get(url) as response:
                content = await response.text()
                soup = BeautifulSoup(content, 'html.parser')

                house_list = soup.select("main > div > div > div > div > ul > li")

                if not any(house.select_one("a[aria-label='Listing link']") for house in house_list):
                    break                

                for house in house_list:
                    page_url = house.select_one("a[aria-label='Listing link']")
                    if page_url:
                        page_url = f"https://www.zameen.com{page_url['href']}"
                        baths = house.select_one("span[aria-label='Baths']")
                        beds = house.select_one("span[aria-label='Beds']")
                        location = house.select_one("div[aria-label='Location']")
                        price = house.select_one("span[aria-label='Price']")
                        size = house.select_one("div[title]>div > div > span:nth-child(1)")
                        date_added = house.select_one("span[aria-label='Listing creation date']")
                        title = soup.select_one("h2[aria-label='Title']")
                        task = scrape_house_details(session, page_url, baths, beds, location, price, size, date_added, title)
                        tasks.append(task)

        house_info.extend(await asyncio.gather(*tasks))

    return house_info

async def main():
    print("asdadca")
    cities = [
        # {'id': 15, 'name': 'Multan'},
        # {'id': 16, 'name': 'Faisalabad'},
        # {'id': 17, 'name': 'Peshawar'},
        # {'id': 18, 'name': 'Quetta'},
        # {'id': 19, 'name': 'Jhelum'},
        # {'id': 20, 'name': 'Gujrat'},
        # {'id': 23, 'name': 'Bahawalpur'},
        # {'id': 26, 'name': 'Dera_Gazi_Khan'},
        # {'id': 30, 'name': 'Hyderabad'},
        # {'id': 2, 'name': 'Karachi'}
        # {'id': 3, 'name': 'Islamabad'},
        # {'id': 1, 'name': 'Lahore'},
        # {'id': 41, 'name': 'Rawalpindi'},
        # {'id': 44, 'name': 'Sheikhupura'},
        {'id': 36, 'name': 'Murree'},
        {'id': 327, 'name': 'Gujranwala'},
        {'id': 385, 'name': 'Abbottabad'},
        {'id': 459, 'name': 'Wah'},
        {'id': 470, 'name': 'Okara'},
        {'id': 480, 'name': 'Sialkot'},
        {'id': 778, 'name': 'Sargodha'},
        {'id': 782, 'name': 'Sahiwal'},
        {'id': 1233, 'name': 'Attock'}
    ]

    with open("zameen_cities_data.csv", "w", newline='') as f:
        csv_writer = csv.writer(f)
        csv_writer.writerow(["city", "location", "price", "bedrooms", "baths", "size", "title", "page_url", "date_added", "property_type", "latitude", "longitude", "number_of_photos", "province", "agency", "purpose"])

        for city in cities:
            city_name = city['name']
            city_id = city['id']
            city_info = await scrape_city(city_name, city_id, 1000)
            for info in city_info:
                csv_writer.writerow([city_name, info.get('location'), info.get('price'), info.get('bedrooms'), info.get('baths'), info.get('size'), info.get('title'), info.get('page_url'), info.get('date_added'), info.get('property_type'), info.get('latitude'), info.get('longitude'), info.get('number_of_photos'), info.get('province'), info.get('agency'), info.get('purpose')])

if __name__ == "__main__":
    asyncio.run(main())
